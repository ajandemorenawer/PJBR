package com.example.suma;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    // 1.- empezamos a declarar lo que vamos a utilizar.
    private EditText et1,et2;
    private TextView tv1;
    private Button bt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 2.- Casteo. Relacionamos cada variable con la parte gráfica.
        // en androide todo son vistas lo de la parte gráfica, botones, edittext, etc
        // usando la clase R
        et1=(EditText)findViewById(R.id.editText);
        et2=(EditText)findViewById(R.id.editText2);
        tv1=(TextView)findViewById(R.id.textView);
        bt1=(Button)findViewById(R.id.button);
    }

    // 3.- Creamos la lógica en el método Sumar
    public void Sumar(View view){
        String valor1_st=et1.getText().toString();
        String valor2_st=et2.getText().toString();

        int valor1_int = Integer.parseInt(valor1_st); // parseo de string a int
        int valor2_int = Integer.parseInt(valor2_st); // parseo de string a int
        int suma = valor1_int + valor2_int;

        String resultado = String.valueOf(suma);

        // mostramos el resultado
        tv1.setText(resultado);

    }
}
